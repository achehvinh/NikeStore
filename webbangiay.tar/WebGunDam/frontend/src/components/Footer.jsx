import React from 'react';
import { Link } from 'react-router-dom';
import { 
  FaFacebook, 
  FaInstagram, 
  FaTwitter, 
  FaMapMarkerAlt, 
  FaPhone, 
  FaEnvelope 
} from 'react-icons/fa';
import '../styles/App.css';

function Footer() {
  return (
    <footer className="app-footer">
      <div className="footer-container">
        <div className="footer-section">
          <h3 className="footer-title">Tới ngay</h3>
          <p className="footer-about">
            ShopGundam - Thương hiệu mô hình Gundam hàng đầu Việt Nam
          </p>
          <div className="social-links">
            <a href="https://facebook.com" target="_blank" rel="noopener noreferrer">
              <FaFacebook />
            </a>
            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer">
              <FaInstagram />
            </a>
            <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">
              <FaTwitter />
            </a>
          </div>
        </div>

        <div className="footer-section">
          <h3 className="footer-title">Liên hệ</h3>
          <ul className="contact-info">
            <li><FaMapMarkerAlt /> 704 Phan Dinh Phung, TP.KonTum</li>
            <li><FaPhone /> 0352.568.951</li>
            <li><FaEnvelope /> info@shopgundam.com</li>
          </ul>
        </div>

        <div className="footer-section">
          <h3 className="footer-title">Chính sách</h3>
          <ul className="policy-links">
            <li><Link to="/policy">CS bảo mật</Link></li>
            <li><Link to="/return">CS đổi trả</Link></li>
            <li><Link to="/shipping">CS vận chuyển</Link></li>
          </ul>
        </div>
      </div>

      <div className="copyright">
        <p>&copy; {new Date().getFullYear()} ShopGundam</p>
      </div>
    </footer>
  );
}

export default Footer;