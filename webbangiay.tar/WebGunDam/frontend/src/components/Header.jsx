import React from 'react';
import { Link } from 'react-router-dom';
import { FaShoppingCart, FaUser } from 'react-icons/fa';
import '../styles/App.css';

function Header() {
  return (
    <header className="app-header">
      <div className="header-container">
        <div className="logo-container">
          <Link to="/" className="logo-link">
            <img 
              src="/images/anh1.jpg" 
              alt="Fashion Shop Logo"
              className="app-logo"
            />
            <span className="brand-name">ShopGundam</span>
          </Link>
        </div>


        <nav className="main-nav">
          <Link to="/cart" className="nav-link cart-link">
            <FaShoppingCart className="nav-icon" />
            <span className="nav-text">Giỏ hàng</span>
            <span className="cart-count">0</span>
          </Link>
          <Link to="/login" className="nav-link">
            <FaUser className="nav-icon" />
            <span className="nav-text">Tài khoản</span>
          </Link>
        </nav>
      </div>
    </header>
  );
}

export default Header;