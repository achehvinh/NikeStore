// File: src/components/ProductCard.jsx
import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/App.css';

function ProductCard({ product }) {
  return (
    <div className="product-card">
      <Link to={`/product/${product.id}`}>
        <img src={product.image} alt={product.name} className="product-image" />
        <h3>{product.name}</h3>
        <p>{product.price.toLocaleString()}đ</p>
      </Link>
    </div>
  );
}

export default ProductCard;