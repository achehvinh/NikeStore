// File: src/pages/Cart.jsx
import React from 'react';

function Cart() {
  return <h2>Giỏ hàng</h2>;
}

export default Cart;