import React, { useState } from 'react';
import ProductCard from '../components/ProductCard';
import gundamModels from '../data/products';
import '../styles/App.css'; // Tạo file CSS mới

function Home() {
  const [searchTerm, setSearchTerm] = useState('');

  // Hàm tìm kiếm sản phẩm
  const filteredProducts = gundamModels.filter((product) => {
  return product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
         product.grade.toLowerCase().includes(searchTerm.toLowerCase());
});


  return (
    <div className="home-page">
      <h1 className="page-title">Trang chủ - Danh sách sản phẩm</h1>
      
      {/* Thanh tìm kiếm */}
      <div className="search-container">
        <input
          type="text"
          placeholder="Tìm kiếm mô hình..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="search-input"
        />
        <button className="search-button">
          <i className="fas fa-search"></i>
        </button>
      </div>

      {/* Danh sách sản phẩm */}
      <div className="product-list">
        {filteredProducts.length > 0 ? (
          filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))
        ) : (
          <div className="no-results">
            <p>Không tìm thấy sản phẩm phù hợp</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default Home;