// File: src/pages/ProductDetail.jsx
import React from 'react';
import { useParams } from 'react-router-dom';

function ProductDetail() {
  const { id } = useParams();
  return <h2>Chi tiết{id}</h2>;
}

export default ProductDetail;