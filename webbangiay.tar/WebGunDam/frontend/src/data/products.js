const gundamModels = [
  {
    id: 1,
    name: "RX-78-2 Gundam",
    image: "https://bizweb.dktcdn.net/100/418/981/products/z5061600085948-565e771a2f075f0e1a7056fdd81ae20a.jpg?v=1743068192973",
    price: 799000,
    grade: "MG",
    series: "Mobile Suit Gundam",
    color: "Trắng/Xanh/Đỏ"
  },
  {
    id: 2,
    name: "Wing Gundam Zero EW",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQprl97735KkxaQtHDOhQStHRJ_of8nV7O85A&s",
    price: 899000,
    grade: "MG",
    series: "Gundam Wing: Endless Waltz",
    color: "Trắng/Xanh"
  },
  {
    id: 3,
    name: "Unicorn Gundam (Destroy Mode)",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7PSPEq-tQDHXxHUZeL2wcvvj_3ru-HOw71Q&s",
    price: 1049000,
    grade: "RG",
    series: "Mobile Suit Gundam Unicorn",
    color: "Trắng/Đỏ"
  },
  {
    id: 4,
    name: "Strike Freedom Gundam",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTrowqrY9MvcHxIYFUB2zCJRbpK_3PRbST9sg&s",
    price: 1199000,
    grade: "MGEX",
    series: "Gundam SEED Destiny",
    color: "Trắng/Vàng/Xanh"
  },
  {
    id: 5,
    name: "Barbatos Lupus Rex",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRwKzyv7HHsxJKCOERPp4NtBXLmShP8IigHvA&s",
    price: 749000,
    grade: "HG",
    series: "Iron-Blooded Orphans",
    color: "Trắng/Vàng"
  },
  {
    id: 6,
    name: "Zaku II (Char's Custom)",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTSx29MzpMk8QNnG2xTvg-SKDZ3sqV9BpZyXw&s",
    price: 599000,
    grade: "HG",
    series: "Mobile Suit Gundam",
    color: "Đỏ"
  },
  {
    id: 7,
    name: "Sinanju Stein (Narrative Ver.)",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1H41bJudULVI30MBVAfmg1ZYYqzXMfebJxg&s",
    price: 1349000,
    grade: "MG",
    series: "Gundam Narrative",
    color: "Xám"
  },
  {
    id: 8,
    name: "Gundam Exia",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTGmIhG49YY1SvVjcwO2zf0GtTilaQRzVKjog&s",
    price: 839000,
    grade: "MG",
    series: "Gundam 00",
    color: "Trắng/Xanh"
  },
  {
    id: 9,
    name: "Gundam Astray Red Frame",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSj3PlvJGXAcPbmppzEO_z8A5pSXbdOJ-L3yg&s",
    price: 889000,
    grade: "MG",
    series: "Gundam SEED Astray",
    color: "Trắng/Đỏ"
  },
  {
    id: 10,
    name: "Gundam Aerial",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSGYZw642PShPgSW6vlJZjQ7wbt75dpA3EuQg&s",
    price: 949000,
    grade: "HG",
    series: "Witch from Mercury",
    color: "Trắng/Xanh"
  },
  {
    id: 11,
    name: "Freedom Gundam",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRrQOkq2PmMXNapseqfNaT9XKfg7dh57QDPfA&s",
    price: 999000,
    grade: "MG",
    series: "Gundam SEED",
    color: "Xanh/Trắng"
  },
  {
    id: 12,
    name: "Gundam Kyrios",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSe9gu03C1uxZmCj9Xbo_sOkWB6j_c8a3zN8g&s",
    price: 769000,
    grade: "HG",
    series: "Gundam 00",
    color: "Cam/Xám"
  },
  {
    id: 13,
    name: "Gundam AGE-1",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQZJ3b5841KNYWIcd1T2gxSwvPReCgvX74Wiw&s",
    price: 689000,
    grade: "HG",
    series: "Gundam AGE",
    color: "Trắng/Xanh"
  },
  {
    id: 14,
    name: "Tallgeese EW",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRmu7evc6HqHmcCttJiQcSHI2VyxRGzg3MnEw&s",
    price: 829000,
    grade: "MG",
    series: "Gundam Wing: Endless Waltz",
    color: "Trắng/Vàng"
  },
  {
    id: 15,
    name: "Gundam Heavyarms",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTz6HUNdkYi1iKw5QqG_FxmzGAuxMzo39mo3w&s",
    price: 899000,
    grade: "MG",
    series: "Gundam Wing",
    color: "Cam/Trắng"
  },
  {
    id: 16,
    name: "Gundam Barbatos",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSjWMph_HzspLDP1Dws4-c5fabBhrfkRfaUiQ&s",
    price: 699000,
    grade: "HG",
    series: "Iron-Blooded Orphans",
    color: "Trắng/Xanh"
  },
  {
    id: 17,
    name: "Zeta Gundam",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS3SJxEfWMP08HhecgOVvPBQ02DFjlslxMZfw&s",
    price: 999000,
    grade: "MG",
    series: "Mobile Suit Zeta Gundam",
    color: "Trắng/Xanh/Đỏ"
  },
  {
    id: 18,
    name: "Gundam F91",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTy45xvrLJsoLRXdaJVwLN2orphk2ZzmtY-cw&s",
    price: 859000,
    grade: "MG",
    series: "Gundam F91",
    color: "Trắng/Xanh"
  },
  {
    id: 19,
    name: "Gundam Deathscythe",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQDkcPmGXULcoQHMhdybaYn8TgGjdcH0-BzCQ&s",
    price: 939000,
    grade: "MG",
    series: "Gundam Wing",
    color: "Đen/Trắng"
  },
  {
    id: 20,
    name: "Gundam Virtue",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ4c-CecQOJ7iei3eU_MoNVBhI93JFeOzuHtg&s",
    price: 1049000,
    grade: "HG",
    series: "Gundam 00",
    color: "Đen/Trắng"
  }
];

export default gundamModels;
