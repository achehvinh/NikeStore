// File: src/services/authService.js
export async function login(email, password) {
  // Giả lập gọi API
  return { success: true, message: `Đăng nhập thành công với ${email}` };
}

export async function register(username, email, password) {
  // Giả lập gọi API
  return { success: true, message: `Tạo tài khoản ${username} thành công` };
}