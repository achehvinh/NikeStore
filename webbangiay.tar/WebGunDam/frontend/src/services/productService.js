// File: src/services/productService.js
import products from '../data/products';

export async function getProducts() {
  // Giả lập API call
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(products);
    }, 300);
  });
}

export async function getProductById(id) {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(products.find(p => p.id === parseInt(id)));
    }, 300);
  });
}