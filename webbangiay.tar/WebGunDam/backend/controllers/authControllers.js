const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const User = require('../models/userModel');

exports.register = async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
        return res.status(400).json({ error: "Thiếu thông tin đăng ký" });
    }

    try {
        const newUser = await User.create({ email, password });
        res.status(201).json({ message: 'Đăng ký thành công!', userId: newUser.id, email: newUser.email });
    } catch (error) {
        console.error("❌ Lỗi khi đăng ký:", error);
        res.status(500).json({ error: "Lỗi server khi tạo user", details: error.message });
    }
};

exports.login = async (req, res) => {
    const { email, password } = req.body;

    try {
        const user = await User.findByEmail(email);

        if (!user) {
            console.error(`❌  Không tìm thấy user với email: ${email}`);
            return res.status(401).json({ message: 'Invalid email or password' });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            console.error(`❌  Password không khớp cho email: ${email}`);
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        console.log("JWT Secret:", process.env.JWT_SECRET);
        const token = jwt.sign({ id: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '1h' }); // Include email in token
        res.json({ token });
    } catch (error) {
        console.error("❌ Lỗi khi đăng nhập:", error);
        res.status(500).json({ error: "Lỗi server khi đăng nhập", details: error.message });
    }
};