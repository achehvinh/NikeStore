const sql = require('mssql');
const poolPromise = require('../config/db').poolPromise;
const Todo = require('../models/todoModel'); // Make sure this is the modified Todo model

exports.getTodos = async (req, res) => {
    try {
        const pool = await poolPromise;
        const result = await pool.request()
            .input('userId', sql.Int, req.user.id)
            .query('SELECT * FROM todos WHERE user_id = @userId');
        res.json(result.recordset);
    } catch (error) {
        console.error("❌ Error fetching todos:", error);
        res.status(500).json({ error: "Failed to fetch todos", details: error.message });
    }
};

exports.addTodo = async (req, res) => {
    const todoData = { ...req.body, user_id: req.user.id };

    try {
        const pool = await poolPromise;
        const result = await pool.request()
            .input('user_id', sql.Int, todoData.user_id)
            .input('title', sql.VarChar, todoData.title) // Adjust data types as needed
            .input('completed', sql.Bit, todoData.completed) //  "completed" as a bit (boolean)
            .query(`
                INSERT INTO todos (user_id, title, completed)
                VALUES (@user_id, @title, @completed);
                SELECT SCOPE_IDENTITY() AS id;
            `);

        const newTodoId = result.recordset[0].id;
        res.status(201).json({ id: newTodoId, ...todoData });
    } catch (error) {
        console.error("❌ Error adding todo:", error);
        res.status(500).json({ error: "Failed to add todo", details: error.message });
    }
};

exports.updateTodo = async (req, res) => {
    const todoId = req.params.id;
    const updateData = req.body;

    try {
        const pool = await poolPromise;
        // Build the SET clause dynamically to handle various fields in updateData
        const setClauses = Object.keys(updateData)
            .map(key => `${key} = @${key}`)
            .join(', ');
        const query = `UPDATE todos SET ${setClauses} WHERE id = @id`;

        const request = pool.request();
        for (const key in updateData) {
            const value = updateData[key];
            let sqlType;
             // Determine the SQL Server data type based on the JavaScript type
            if (typeof value === 'string') {
                sqlType = sql.VarChar;
            } else if (typeof value === 'number') {
                sqlType = sql.Int;
            } else if (typeof value === 'boolean') {
                sqlType = sql.Bit;
            }  // Add more data type checks as needed for your todo schema
            else{
                 sqlType = sql.VarChar; //default
            }
            request.input(key, sqlType, value); // Use dynamic parameter names
        }
        request.input('id', sql.Int, todoId);  // Always include the id parameter

        const result = await request.query(query);

        if (result.rowsAffected[0] > 0) {
            res.json({ message: 'Todo updated' });
        } else {
            res.status(404).json({ message: 'Todo not found' }); // Handle the case where no rows were updated
        }


    } catch (error) {
        console.error("❌ Error updating todo:", error);
        res.status(500).json({ error: "Failed to update todo", details: error.message });
    }
};

exports.deleteTodo = async (req, res) => {
    const todoId = req.params.id;

    try {
        const pool = await poolPromise;
        const result = await pool.request()
            .input('id', sql.Int, todoId)
            .query('DELETE FROM todos WHERE id = @id');

            if (result.rowsAffected[0] > 0) {
                res.json({ message: 'Todo deleted' });
            } else {
                res.status(404).json({ message: 'Todo not found' }); // Handle the case where no rows were deleted
            }

    } catch (error) {
        console.error("❌ Error deleting todo:", error);
        res.status(500).json({ error: "Failed to delete todo", details: error.message });
    }
};
