const sql = require('mssql');
const poolPromise = require('../config/db').poolPromise;

const Todo = {
    findAllByUserId: async (userId) => {
        try {
            const pool = await poolPromise;
            const result = await pool.request()
                .input('userId', sql.Int, userId)
                .query('SELECT * FROM todos WHERE user_id = @userId');
            return result.recordset;
        } catch (error) {
            console.error("❌ Error in findAllByUserId:", error);
            throw error; // Re-throw the error for the controller to handle
        }
    },

    create: async (todoData) => {
        try {
            const pool = await poolPromise;
            const result = await pool.request()
                .input('user_id', sql.Int, todoData.user_id)
                .input('title', sql.VarChar, todoData.title)
                .input('completed', sql.Bit, todoData.completed) // Assuming completed is a bit (boolean)
                .query(`
                    INSERT INTO todos (user_id, title, completed) 
                    VALUES (@user_id, @title, @completed);
                    SELECT SCOPE_IDENTITY() AS id;
                `);
            return { id: result.recordset[0].id, ...todoData }; // Include the passed data
        } catch (error) {
            console.error("❌ Error in create:", error);
            throw error;
        }
    },

    update: async (id, updateData) => {
        try {
            const pool = await poolPromise;

            // Dynamically build the SET clause and parameters
            const setClauses = Object.keys(updateData)
                .map(key => `${key} = @${key}`)
                .join(', ');
            const query = `UPDATE todos SET ${setClauses} WHERE id = @id`;

            const request = pool.request();
            for (const key in updateData) {
                const value = updateData[key];
                let sqlType;
                // Determine the SQL Server data type based on the JavaScript type
                if (typeof value === 'string') {
                    sqlType = sql.VarChar;
                } else if (typeof value === 'number') {
                    sqlType = sql.Int;
                } else if (typeof value === 'boolean') {
                    sqlType = sql.Bit;
                } else {
                    sqlType = sql.VarChar; // Default
                }
                request.input(key, sqlType, value);
            }
            request.input('id', sql.Int, id);

            const result = await request.query(query);
            return result.rowsAffected[0]; // Return number of affected rows (0 or 1)
        } catch (error) {
            console.error("❌ Error in update:", error);
            throw error;
        }
    },

    delete: async (id) => {
        try {
            const pool = await poolPromise;
            const result = await pool.request()
                .input('id', sql.Int, id)
                .query('DELETE FROM todos WHERE id = @id');
            return result.rowsAffected[0]; // Return number of affected rows
        } catch (error) {
            console.error("❌ Error in delete:", error);
            throw error;
        }
    }
};

module.exports = Todo;
