const sql = require('mssql');
const poolPromise = require('../config/db').poolPromise;
const bcrypt = require('bcrypt'); // Import bcrypt for password hashing

const User = {
    findByEmail: async (email) => {
        try {
            const pool = await poolPromise;
            const result = await pool.request()
                .input('email', sql.VarChar, email)
                .query('SELECT id, email, password FROM users WHERE email = @email'); // Corrected query
            return result.recordset[0];
        } catch (error) {
            console.error("❌ Error in findByEmail:", error);
            throw error;
        }
    },

    create: async (userData) => {
        try {
            const pool = await poolPromise;
            const hashedPassword = await bcrypt.hash(userData.password, 10); // Hash the password
            const result = await pool.request()
                .input('email', sql.VarChar, userData.email)
                .input('password', sql.VarChar, hashedPassword) // Use hashed password
                .query(`
                    INSERT INTO users (email, password)
                    VALUES (@email, @password);
                    SELECT SCOPE_IDENTITY() AS id;
                `);
            return { id: result.recordset[0].id, email: userData.email }; // Return relevant user data
        } catch (error) {
            console.error("❌ Error in create:", error);
            throw error;
        }
    }
};

module.exports = User;
